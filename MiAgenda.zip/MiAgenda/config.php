<?php
$con = mysqli_connect('localhost','root','','calendar_drag');
?>